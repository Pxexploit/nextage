<?php
session_start();

// Verifica se o usuário está logado e é admin
if (!isset($_SESSION['usuario_email']) || $_SESSION['usuario_tipo'] !== 'admin') {
    echo "Acesso negado.";
    exit();
}

// Conexão com o banco de dados
$conn = new mysqli("localhost", "root", "", "sistema_login");

if ($conn->connect_error) {
    die("Erro na conexão: " . $conn->connect_error);
}

// Pega o ID da loja a ser excluída
$id_loja = isset($_POST['id_loja']) ? intval($_POST['id_loja']) : null;

if (!$id_loja) {
    echo "ID da loja não fornecido.";
    exit();
}

// Verifica se a loja existe
$verifica = $conn->prepare("SELECT id_loja FROM loja WHERE id_loja = ?");
$verifica->bind_param("i", $id_loja);
$verifica->execute();
$result = $verifica->get_result();

if ($result->num_rows === 0) {
    echo "Loja não encontrada.";
    exit();
}

// Inicia transação
$conn->begin_transaction();

try {
    // Desvincular produtos
    $stmt = $conn->prepare("UPDATE produto SET id_loja = NULL WHERE id_loja = ?");
    $stmt->bind_param("i", $id_loja);
    $stmt->execute();

    // Desvincular vendas
    $stmt = $conn->prepare("UPDATE venda SET id_loja = NULL WHERE id_loja = ?");
    $stmt->bind_param("i", $id_loja);
    $stmt->execute();

    // Desvincular vendedores
    $stmt = $conn->prepare("UPDATE vendedor SET id_loja = NULL WHERE id_loja = ?");
    $stmt->bind_param("i", $id_loja);
    $stmt->execute();

    // Excluir loja
    $stmt = $conn->prepare("DELETE FROM loja WHERE id_loja = ?");
    $stmt->bind_param("i", $id_loja);
    $stmt->execute();

    // Confirma transação
    $conn->commit();

    // Redireciona com notificação de sucesso
    header("Location: painelAdmin.php?excluido=1&tipo=loja");
    exit();
} catch (Exception $e) {
    // Reverte alterações em caso de erro
    $conn->rollback();
    echo "Erro ao excluir loja: " . $e->getMessage();
} finally {
    $conn->close();
}
