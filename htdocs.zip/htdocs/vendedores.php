<?php
session_start();
include('conexao.php');

if (!isset($_SESSION['usuario_id']) || $_SESSION['usuario_tipo'] !== 'admin') {
    echo "Acesso negado.";
    exit();
}

$result = $conn->query("SELECT * FROM vendedor");

echo "<h2>Lista de Vendedores</h2>";
echo "<table border='1' cellpadding='5'>";
echo "<tr><th>ID</th><th>Nome</th><th>Email</th><th>Ações</th></tr>";

while ($v = $result->fetch_assoc()) {
    echo "<tr>
        <td>{$v['id_vendedor']}</td>
        <td>{$v['nome']}</td>
        <td>{$v['email']}</td>
        <td>
            <a href='editar_vendedor.php?id={$v['id_vendedor']}'>Editar</a> |
            <a href='excluir_vendedor.php?id={$v['id_vendedor']}' onclick=\"return confirm('Deseja realmente excluir?')\">Excluir</a>
        </td>
    </tr>";
}
echo "</table>";
