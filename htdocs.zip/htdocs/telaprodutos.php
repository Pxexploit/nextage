<?php
session_start();

if (!isset($_SESSION['usuario_id']) || !in_array($_SESSION['usuario_tipo'], ['cliente', 'vendedor'])) {
    header("Location: login.php");
    exit();
}

$servername = "localhost"; 
$username = "root";
$password = ""; 
$dbname = "sistema_login"; 

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}

$categoryFilter = isset($_GET['category']) ? $_GET['category'] : 'todos';

$MAX_PRICE_ALLOWED = 9999999999.99;
$MIN_PRICE_ALLOWED = 0;

function sanitize_price($price, $min, $max) {
    if (!is_numeric($price)) return $min;
    $price = floatval($price);
    if ($price < $min) return $min;
    if ($price > $max) return $max;
    return $price;
}

$minPrice = isset($_GET['min-price']) ? sanitize_price($_GET['min-price'], $MIN_PRICE_ALLOWED, $MAX_PRICE_ALLOWED) : $MIN_PRICE_ALLOWED;
$maxPrice = isset($_GET['max-price']) ? sanitize_price($_GET['max-price'], $MIN_PRICE_ALLOWED, $MAX_PRICE_ALLOWED) : $MAX_PRICE_ALLOWED;

if ($minPrice > $maxPrice) {
    $maxPrice = $minPrice;
}

$sql = "SELECT 
            produto.id_produto,
            produto.nome AS nome_produto, 
            produto.descricao, 
            produto.preco, 
            produto.imagem,  
            loja.nome AS nome_loja, 
            vendedor.nome AS nome_vendedor, 
            vendedor.email,
            loja.telefone
        FROM produto 
        INNER JOIN loja ON produto.id_loja = loja.id_loja
        INNER JOIN vendedor ON vendedor.id_loja = loja.id_loja
        WHERE produto.preco BETWEEN ? AND ?";

if ($categoryFilter !== 'todos') {
    $sql .= " AND produto.descricao LIKE ?";
    $stmt = $conn->prepare($sql);
    $searchCategoria = '%' . $categoryFilter . '%';
    $stmt->bind_param("dds", $minPrice, $maxPrice, $searchCategoria);
} else {
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("dd", $minPrice, $maxPrice);
}

$stmt->execute();
$result = $stmt->get_result();

$produtos = [];
while ($row = $result->fetch_assoc()) {
    $produtos[$row['id_produto']] = $row;
}

if (isset($_GET['produto']) && isset($produtos[$_GET['produto']])) {
    $id = intval($_GET['produto']);
    $preco_produto = $produtos[$id]['preco'];

    if (!isset($_SESSION['carrinho'])) {
        $_SESSION['carrinho'] = [];
    }

    if (!isset($_SESSION['carrinho'][$id])) {
        $_SESSION['carrinho'][$id] = 0;
    }
    $_SESSION['carrinho'][$id]++;

    if (isset($_SESSION['usuario_id']) && $_SESSION['usuario_tipo'] === 'cliente') {
        $usuario_id = $_SESSION['usuario_id'];
        $produto_id = $id;
        $quantidade = 1;
        $valor_unitario = $preco_produto;

        $stmt_venda = $conn->prepare("SELECT id_venda FROM venda WHERE id_cliente = ? AND status = 'carrinho'");
        $stmt_venda->bind_param("i", $usuario_id);
        $stmt_venda->execute();
        $result_venda = $stmt_venda->get_result();

        if ($result_venda->num_rows > 0) {
            $venda = $result_venda->fetch_assoc();
            $id_venda = $venda['id_venda'];
        } else {
            $stmt_nova = $conn->prepare("INSERT INTO venda (id_cliente, status) VALUES (?, 'carrinho')");
            $stmt_nova->bind_param("i", $usuario_id);
            $stmt_nova->execute();
            $id_venda = $stmt_nova->insert_id;
        }

        $stmt_check = $conn->prepare("SELECT item_quantidade FROM item_venda WHERE id_venda = ? AND id_produto = ?");
        $stmt_check->bind_param("ii", $id_venda, $produto_id);
        $stmt_check->execute();
        $res_check = $stmt_check->get_result();

        if ($res_check->num_rows > 0) {
            $stmt_update = $conn->prepare("UPDATE item_venda SET item_quantidade = item_quantidade + 1 WHERE id_venda = ? AND id_produto = ?");
            $stmt_update->bind_param("ii", $id_venda, $produto_id);
            $stmt_update->execute();
        } else {
            $stmt = $conn->prepare("INSERT INTO item_venda (id_venda, id_produto, item_quantidade, item_valor) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("iiid", $id_venda, $produto_id, $quantidade, $valor_unitario);
            $stmt->execute();
        }
    }

    header('Location: ' . $_SERVER['PHP_SELF']);
    exit;
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Marketplace - Produtos</title>
    <link rel="stylesheet" href="css/telaproduto.css">
</head>
<body>

<div id="mensagemCarrinho" style="display: none;">
    Apenas clientes têm acesso ao carrinho.
</div>


<header>
    <div class="logo">
        <img src="images/site2.png" alt="Logo" style="width: 4.7rem;">
    </div>
    <div class="search-bar">
        <input type="text" placeholder="Buscar produtos..." id="search-input" oninput="searchProducts()" autocomplete="off">
    </div>

    <div class="filters">
        <a href="../php/<?php echo $_SESSION['usuario_tipo'] === 'vendedor' ? 'siteVendedor.php' : 'site.php'; ?>" class="btn-voltar-header">
            <img src="images/voltar.png" alt="Voltar">
        </a>

        <?php
            $ehCliente = isset($_SESSION['usuario_tipo']) && $_SESSION['usuario_tipo'] === 'cliente';
            $linkCarrinho = $ehCliente ? 'carrinho.php' : '#';
            $eventoClique = $ehCliente ? '' : 'onclick="exibirMensagemCarrinho(); return false;"';
        ?>
        <a href="<?php echo $linkCarrinho; ?>" class="cart-button" <?php echo $eventoClique; ?>>
            <img src="images/carrinho.png" alt="Carrinho de Compras" style="width: 2.5rem;">
        </a>
    </div>
</header>

<div class="filters-section" id="filters-section" style="display: none;">
    <form action="" method="GET">
        <select name="category" id="category">
            <option value="todos" <?php echo $categoryFilter == 'todos' ? 'selected' : ''; ?>>Todas as Categorias</option>
            <option value="eletronicos" <?php echo $categoryFilter == 'eletronicos' ? 'selected' : ''; ?>>Eletrônicos</option>
            <option value="roupas" <?php echo $categoryFilter == 'roupas' ? 'selected' : ''; ?>>Roupas</option>
            <option value="moveis" <?php echo $categoryFilter == 'moveis' ? 'selected' : ''; ?>>Móveis</option>
        </select>
        <input type="number" placeholder="Preço mínimo" name="min-price" value="<?php echo $minPrice; ?>" oninput="searchProducts()">
        <input type="number" placeholder="Preço máximo" name="max-price" value="<?php echo $maxPrice; ?>" oninput="searchProducts()">
        <button type="submit">Aplicar Filtros</button>
    </form>
</div>


<div class="filters-section" id="filters-section">
    <form action="" method="GET">
        <label for="min-price">Preço Mínimo</label>
        <input type="number" placeholder="Preço mínimo" name="min-price" id="min-price" value="<?php echo isset($_GET['min-price']) ? $_GET['min-price'] : 0; ?>" oninput="searchProducts()">
        <label for="max-price">Preço Máximo</label>
        <input type="number" placeholder="Preço máximo" name="max-price" id="max-price" value="<?php echo isset($_GET['max-price']) ? $_GET['max-price'] : 999999; ?>" oninput="searchProducts()">
    </form>
</div>

<section class="product-list" id="product-list">
    <?php
    if (count($produtos) > 0) {
        foreach ($produtos as $produto) {
            ?>
            <div class="product-card" data-produto-id="<?php echo $produto['id_produto']; ?>">
                <img src="uploads/<?php echo htmlspecialchars($produto['imagem']); ?>" alt="<?php echo htmlspecialchars($produto['nome_produto']); ?>">
                <div class="product-details">
                    <h3 class="product-name"><?php echo htmlspecialchars($produto['nome_produto']); ?></h3>
                    <p class="product-description"><?php echo htmlspecialchars($produto['descricao']); ?></p>
                    <span class="product-price">R$ <?php echo number_format($produto['preco'], 2, ',', '.'); ?></span><br>
                    <span class="product-store">Loja: <?php echo htmlspecialchars($produto['nome_loja']); ?></span><br>
                    <span class="product-seller">Vendedor: <?php echo htmlspecialchars($produto['nome_vendedor']); ?></span>

                    <div class="button-group">
                        <a href="https://wa.me/<?php echo preg_replace('/\D/', '', $produto['telefone']); ?>" class="contact-button" target="_blank">
                            Contato via WhatsApp
                        </a>
                        <a href="?produto=<?php echo $produto['id_produto']; ?>" class="add-cart-button">
                            <img src="images/addcarrinho.png" alt="Adicionar ao Carrinho" style="width: 2rem;">
                        </a>
                    </div>
                </div>
            </div>
            <?php
        }
    } else {
        echo "<p>Nenhum produto encontrado.</p>";
    }
    ?>
</section>

<footer>
    <div class="footer-links">
        <a href="/sobre">Sobre</a>
        <a href="/politica-privacidade">Política de Privacidade</a>
        <a href="/termos-uso">Termos de Uso</a>
    </div>
    <div class="footer-info">
        <p>© 2025 TaquaMarket. Todos os direitos reservados.</p>
    </div>
</footer>

<script>
function searchProducts() {
    var query = document.getElementById('search-input').value.trim();  // Obtém o texto digitado
    var minPrice = document.getElementById('min-price').value.trim();  // Obtém o preço mínimo
    var maxPrice = document.getElementById('max-price').value.trim();  // Obtém o preço máximo

    if (query.length > 0 || minPrice.length > 0 || maxPrice.length > 0) {  // Se houver qualquer filtro
        var xhr = new XMLHttpRequest();
        xhr.open("GET", "search_products.php?search=" + query + "&min-price=" + minPrice + "&max-price=" + maxPrice, true);  // URL do arquivo PHP com a pesquisa e filtros

        xhr.onreadystatechange = function () {
            if (xhr.readyState == 4 && xhr.status == 200) {
                // Atualiza a seção de produtos com o retorno do PHP
                document.getElementById('product-list').innerHTML = xhr.responseText;
            }
        };

        xhr.send();
    } else {
        // Se não houver nada digitado ou filtrado, exibe novamente todos os produtos
        location.reload();  // Isso vai recarregar a página e exibir todos os produtos novamente
    }
}
</script>

</body>
</html>

<?php $conn->close(); ?>
