<?php
session_start(); 

$mensagemacerto = "Faça o Login";
$texto = "";

if (isset($_SESSION['deubom']) && $_SESSION['deubom'] == 'positivo') {
    $mensagemacerto = "Cadastro Realizado com sucesso!";
} else if ((isset($_SESSION['deubom']) && $_SESSION['deubom'] == 'LOG')) {
    $mensagemacerto = "Usuário Desconectado!";
    session_destroy();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['botaosubmit'])) {
        $servername = "localhost";
        $username = "root"; 
        $password = ""; 
        $dbname = "sistema_login";

        $conn = new mysqli($servername, $username, $password, $dbname);

        if ($conn->connect_error) {
            die("Falha na conexão: " . $conn->connect_error);
        }

        $email = $_POST['email'];
        $senha = $_POST['senha'];

        $sql_cliente = "SELECT * FROM cliente WHERE email = '$email'";
        $result_cliente = $conn->query($sql_cliente);

        $sql_vendedor = "SELECT * FROM vendedor WHERE email = '$email'";
        $result_vendedor = $conn->query($sql_vendedor);

        $usuario = null;
        $tipo_usuario = "";

        if ($result_cliente->num_rows > 0) {
            $usuario = $result_cliente->fetch_assoc();
            $tipo_usuario = 'cliente';
        } else if ($result_vendedor->num_rows > 0) {
            $usuario = $result_vendedor->fetch_assoc();
            $tipo_usuario = 'vendedor';
        }

        if ($usuario) {
            if (password_verify($senha, $usuario['senha'])) {
                $_SESSION['usuario_email'] = $usuario['email'];
                $_SESSION['usuario_tipo'] = $tipo_usuario;

                if ($tipo_usuario === 'vendedor') {
                    $_SESSION['usuario_id'] = $usuario['id_vendedor'];
                    header("Location: php/siteVendedor.php");
                } else {
                    $_SESSION['usuario_id'] = $usuario['id_cliente'];
                    header("Location: php/site.php");
                }
                exit();
            } else {
                $texto = "Senha incorreta!";
            }
        } else {
            $texto = "Usuário não encontrado!";
        }

        $conn->close();
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="../css/styleslogin.css">
    <style>
        #mensagem {
            padding: 4px;
            color: rgba(196, 28, 28, 0.92);
        }

        .login-input::placeholder {
            color: rgba(255, 255, 255, 0.5);
            transition: color 0.3s ease;
        }

        .login-input:focus::placeholder {
            color: transparent;
        }

        #particles-js {
            position: absolute;
            width: 100%;
            height: 100%;
            z-index: -1;
            opacity: 1; 
        }

        .particle {
            position: absolute;
            width: 15px;
            height: 15px;
            border-radius: 50%;
            background-color: #3498db;
            pointer-events: none;
            transition: transform 0.1s ease;
            box-shadow: 0 0 10px rgba(52, 152, 219, 0.6);
        }
    </style>
</head>
<body>
<div class="container">
    <div id="mensagemdeubom"><?php echo $mensagemacerto; ?></div>

    <div class="form-container">
         <h2>Login de Usuário</h2>
        <form action="" method="POST">
            <div class="input-group">
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" required class="login-input">
            </div>
            
            <div class="input-group">
                <label for="senha">Senha:</label>
                <input type="password" id="senha" name="senha" required class="login-input">
                <div id="mensagem"><?php echo $texto; ?></div>
            </div>

            <button type="submit" name="botaosubmit">Entrar</button>
            <p>Ainda não tem uma conta? <a href="../register.php">Cadastre-se aqui.</a></p>
        </form>
    </div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/particles.js/2.0.0/particles.min.js"></script>
<div id="particles-js"></div>
<div class="particle"></div>
<script>
    function initParticles() {
        particlesJS('particles-js', {
            "particles": {
                "number": {
                    "value": 30,
                    "density": {
                        "enable": true,
                        "value_area": 800
                    }
                },
                "color": { "value": "#ffffff" },
                "shape": {
                    "type": "circle",
                    "stroke": { "width": 0, "color": "#ffffff" }
                },
                "opacity": { "value": 0.7, "random": false },
                "size": { "value": 4, "random": true },
                "line_linked": { "enable": false },
                "move": {
                    "enable": true,
                    "speed": 3,
                    "direction": "none",
                    "out_mode": "out"
                }
            },
            "interactivity": { "events": { "resize": true } },
            "retina_detect": true
        });
    }

    initParticles();

    const particle = document.querySelector('.particle');
    document.addEventListener('mousemove', (e) => {
        const mouseX = e.clientX;
        const mouseY = e.clientY;
        particle.style.left = mouseX - particle.offsetWidth / 2 + 'px';
        particle.style.top = mouseY - particle.offsetHeight / 2 + 'px';
    });
</script>
</body>
</html>
