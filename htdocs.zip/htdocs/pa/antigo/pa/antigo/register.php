<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro de Usuário</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/particles.js/2.0.0/particles.min.css">
    <link rel="stylesheet" href="css/stylesregister.css">
    <style>
        #mensagemerro {
            padding: 4px;
            color: rgba(196, 28, 28, 0.92);
        }

        #particles-js {
            position: absolute;
            width: 100%;
            height: 100%;
            z-index: -1;
            opacity: 1; 
        }

        .particle {
            position: absolute;
            width: 15px;
            height: 15px;
            border-radius: 50%;
            background-color: #3498db;
            pointer-events: none;
            transition: transform 0.1s ease;
            box-shadow: 0 0 10px rgba(52, 152, 219, 0.6);
        }
    </style>
</head>
<body>

<?php
$erro = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['botaosubmit'])) {
        $conn = new mysqli("localhost", "root", "", "sistema_login");

        if ($conn->connect_error) {
            die("Conexão falhou: " . $conn->connect_error);
        }

        $nome = $_POST['nome'];
        $email = $_POST['email'];
        $senha = password_hash($_POST['senha'], PASSWORD_DEFAULT); 
        $tipo_usuario = $_POST['tipo_usuario'];

        // Verifica se o email já está em cliente ou vendedor
        $sql_check = "SELECT email FROM cliente WHERE email = '$email' 
                      UNION 
                      SELECT email FROM vendedor WHERE email = '$email'";
        $result_check = $conn->query($sql_check);

        if ($result_check->num_rows > 0) {
            $erro = "Este email já está registrado!";
        } else {
            if ($tipo_usuario === 'cliente') {
                // Inserção para cliente
                $sql_insert = "INSERT INTO cliente (nome, email, senha) 
                               VALUES ('$nome', '$email', '$senha')";
            } elseif ($tipo_usuario === 'vendedor') {
                // Inserção de vendedor SEM loja (id_loja NULL)
                $sql_insert = "INSERT INTO vendedor (nome, email, senha, id_loja)  
                               VALUES ('$nome', '$email', '$senha', NULL)";
            }

            if ($conn->query($sql_insert) === TRUE) {
                session_start();
                $_SESSION['deubom'] = 'positivo';
                header("Location: ../login.php");
                exit; 
            } else {
                $erro = "Erro ao cadastrar usuário: " . $conn->error;
            }
        }

        $conn->close();
    }
}
?>

<div class="container">
    <div class="form-container">
        <h2>Cadastro de Usuário</h2>
        <form action="" method="POST">
            <div class="input-group">
                <label for="nome">Nome:</label>
                <input type="text" id="nome" name="nome" required>
            </div>

            <div class="input-group">
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" required>
            </div>

            <div class="input-group">
                <label for="senha">Senha:</label>
                <input type="password" id="senha" name="senha" required>
                <div id="mensagemerro"><?php echo $erro; ?></div>
            </div>

            <div class="input-group">
                <label for="tipo_usuario">Tipo de Conta:</label>
                <select name="tipo_usuario" id="tipo_usuario" required>
                    <option value="cliente">Cliente</option>
                    <option value="vendedor">Vendedor</option>
                </select>
            </div>

            <button type="submit" name="botaosubmit">Cadastrar</button>
            <p>Já tem uma conta? <a href="login.php">Faça login aqui.</a></p>
        </form>
    </div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/particles.js/2.0.0/particles.min.js"></script>
<div id="particles-js"></div>
<div class="particle"></div>
<script>

  // Configura as partículas
  function initParticles() {
            particlesJS('particles-js', {
                "particles": {
                    "number": {
                        "value": 30, // Aumentado o número de partículas
                        "density": {
                            "enable": true,
                            "value_area": 800
                        }
                    },
                    "color": {
                        "value": "#ffffff"
                    },
                    "shape": {
                        "type": "circle",
                        "stroke": {
                            "width": 0,
                            "color": "#ffffff"
                        }
                    },
                    "opacity": {
                        "value": 0.7,
                        "random": false
                    },
                    "size": {
                        "value": 4,
                        "random": true
                    },
                    "line_linked": {
                        "enable": false
                    },
                    "move": {
                        "enable": true,
                        "speed": 3, // Ajustado para um movimento mais suave
                        "direction": "none",
                        "out_mode": "out"
                    }
                },
                "interactivity": {
                    "events": {
                        "resize": true
                    }
                },
                "retina_detect": true
            });
        }

        // Inicializa as partículas
        initParticles();

const particle = document.querySelector('.particle');

document.addEventListener('mousemove', (e) => {
    const mouseX = e.clientX;
    const mouseY = e.clientY;

    // Atualiza a posição da partícula para seguir o mouse
    particle.style.left = mouseX - particle.offsetWidth / 2 + 'px';
    particle.style.top = mouseY - particle.offsetHeight / 2 + 'px';
});

</script>
</body>
</html>
