<?php
$cadastroSucesso = false;
$verifica = false;
$mensagem = "";
session_start();

// Função para formatar CPF ou CNPJ
function formatarCpfCnpj($numero) {
    $numero = preg_replace('/\D/', '', $numero);

    if (strlen($numero) === 11) {
        // CPF: 000.000.000-00
        return preg_replace('/(\d{3})(\d{3})(\d{3})(\d{2})/', '$1.$2.$3-$4', $numero);
    } elseif (strlen($numero) === 14) {
        // CNPJ: 00.000.000/0000-00
        return preg_replace('/(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})/', '$1.$2.$3/$4-$5', $numero);
    } else {
        return $numero;
    }
}

// Verificação de acesso apenas para vendedores
if (!isset($_SESSION['usuario_email']) || $_SESSION['usuario_tipo'] !== 'vendedor') {
    echo "Você precisa estar logado como vendedor para acessar esta página.";
    exit();
} else {
    $conn = new mysqli("localhost", "root", "", "sistema_login");
    if ($conn->connect_error) {
        die("Falha na conexão: " . $conn->connect_error);
    }

    $stmt_vend = $conn->prepare("SELECT * FROM vendedor WHERE email = ?");
    $stmt_vend->bind_param("s", $_SESSION['usuario_email']);
    $stmt_vend->execute();
    $res_vend = $stmt_vend->get_result();
    $vendedor = $res_vend->fetch_assoc();
    $id_loja = $vendedor['id_loja'];

    if (!is_null($id_loja)) {
        $verifica = true;
        $stmt_loja = $conn->prepare("SELECT * FROM loja WHERE id_loja = ?");
        $stmt_loja->bind_param("i", $id_loja);
        $stmt_loja->execute();
        $res_loja = $stmt_loja->get_result();
        $loja = $res_loja->fetch_assoc();
        $mensagem = "Você já possui uma loja cadastrada no nosso sistema!";
    }

    if ($_SERVER["REQUEST_METHOD"] === "POST" && !$verifica) {
        $email_vendedor = $_SESSION['usuario_email'];
        $nome_loja = $_POST['nome_loja'];
        $endereco_loja = $_POST['endereco_loja'];
        $telefone_loja = $_POST['telefone_loja'];
        $cnpj_cpf_input = preg_replace('/[^0-9]/', '', $_POST['cnpj_cpf_loja']);

        $cnpj = null;
        $cpf = null;
        if (strlen($cnpj_cpf_input) === 14) {
            $cnpj = $cnpj_cpf_input;
        } elseif (strlen($cnpj_cpf_input) === 11) {
            $cpf = $cnpj_cpf_input;
        } else {
            $mensagem = "CNPJ ou CPF inválido.";
        }

        if (empty($mensagem)) {
            $stmt_loja = $conn->prepare("INSERT INTO loja (nome, endereco, telefone, cnpj, cpf) VALUES (?, ?, ?, ?, ?)");
            if ($stmt_loja === false) {
                die('Erro ao preparar a consulta: ' . $conn->error);
            }

            $stmt_loja->bind_param("sssss", $nome_loja, $endereco_loja, $telefone_loja, $cnpj, $cpf);

            if ($stmt_loja->execute()) {
                $id_loja = $conn->insert_id;

                $stmt_vend = $conn->prepare("UPDATE vendedor SET id_loja = ? WHERE email = ?");
                $stmt_vend->bind_param("is", $id_loja, $email_vendedor);

                if ($stmt_vend->execute()) {
                    $mensagem = "Loja cadastrada com sucesso e vinculada ao vendedor!";
                    $cadastroSucesso = true;
                    $verifica = true;

                    $stmt_loja = $conn->prepare("SELECT * FROM loja WHERE id_loja = ?");
                    $stmt_loja->bind_param("i", $id_loja);
                    $stmt_loja->execute();
                    $res_loja = $stmt_loja->get_result();
                    $loja = $res_loja->fetch_assoc();
                } else {
                    $mensagem = "Erro ao vincular loja ao vendedor: " . $stmt_vend->error;
                }
            } else {
                $mensagem = "Erro ao cadastrar loja: " . $stmt_loja->error;
            }

            $stmt_loja->close();
        }
    }

    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastrar Loja</title>
    <link rel="stylesheet" href="../css/cdstroloja.css">
    <script src="https://unpkg.com/imask"></script>
</head>
<body>

<?php if (!empty($mensagem)): ?>
    <div id="mensagemdeubom" style="font-weight: bold;">
        <?php echo $mensagem; ?>
    </div>
<?php endif; ?>

<?php if (!$verifica): ?>
    <div class="container">
        <h2>Cadastrar Loja</h2>
        <form action="" method="POST">
            <label for="nome_loja">Nome da Loja:</label>
            <input type="text" id="nome_loja" name="nome_loja" required>

            <label for="endereco_loja">Endereço da Loja:</label>
            <input type="text" id="endereco_loja" name="endereco_loja" required>

            <label for="telefone_loja">Telefone/WhatsApp da Loja:</label>
            <input type="text" id="telefone_loja" name="telefone_loja" required>

            <label for="cnpj_cpf_loja">CNPJ ou CPF da Loja:</label>
            <input type="text" id="cnpj_cpf_loja" name="cnpj_cpf_loja" required>

            <button type="submit">Cadastrar Loja</button>
            <button type="button" onclick="window.location.href='../php/MenuVendedor.php'">Voltar ao Menu</button>
        </form>
    </div>
<?php endif; ?>

<?php if ($verifica): ?>
    <div class="container">
        <h2>Loja Cadastrada</h2>
        <p><strong>Nome da Loja:</strong> <?php echo $loja['nome']; ?></p>
        <p><strong>Endereço:</strong> <?php echo $loja['endereco']; ?></p>
        <p><strong>Telefone/WhatsApp:</strong> <?php echo $loja['telefone']; ?></p>
        <p><strong>CPF/CNPJ:</strong> <?php echo formatarCpfCnpj($loja['cnpj'] ?? $loja['cpf']); ?></p>

        <form action="../php/editar_loja.php" method="GET">
            <button type="submit">Editar Cadastro da Loja</button>
        </form>
        <form action="../php/excluir_loja.php" method="POST" onsubmit="return confirm('Tem certeza que deseja excluir a loja?');">
            <button type="submit" style="background-color: red;">Excluir Loja</button>
        </form>
        <form action="../php/MenuVendedor.php" method="GET">
            <button type="submit">Voltar ao Menu</button>
        </form>
    </div>
<?php endif; ?>

<?php if ($cadastroSucesso): ?>
    <script>
        document.getElementById("nome_loja").disabled = true;
        document.getElementById("endereco_loja").disabled = true;
        document.getElementById("telefone_loja").disabled = true;
        document.getElementById("cnpj_cpf_loja").disabled = true;
    </script>
<?php endif; ?>

<script>
    // Máscara de telefone
    var telefoneInput = document.getElementById('telefone_loja');
    if (telefoneInput) {
        IMask(telefoneInput, {
            mask: '(00) 00000-0000'
        });
    }

    // Máscara dinâmica de CPF ou CNPJ
    var cnpjCpfInput = document.getElementById('cnpj_cpf_loja');
    if (cnpjCpfInput) {
        IMask(cnpjCpfInput, {
            mask: [
                {
                    mask: '000.000.000-00'
                },
                {
                    mask: '00.000.000/0000-00'
                }
            ],
            dispatch: function (appended, dynamicMasked) {
                var number = (dynamicMasked.value + appended).replace(/\D/g, '');
                return number.length <= 11 ? dynamicMasked.compiledMasks[0] : dynamicMasked.compiledMasks[1];
            }
        });
    }
</script>

</body>
</html>
