<?php
session_start();

if (isset($_SESSION['usuario_email']) && $_SESSION['usuario_tipo'] === 'vendedor') {
    // exibir o HTML
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Marketplace Taquaritinga-SP</title>
    <link href="../css/imports_new.css" rel="stylesheet">
    <script src="../js/jquery.min.js"></script>
    <link href="../css/remixicon.css" rel="stylesheet">
    <link rel="shortcut icon" type="image/x-icon" href="../images/site2.png">
    
</head>
<body>

        
<style>
    
</style>

<header id="navbar">
    <div class="container">
        <nav class="navbar navbar-expand-xl navbar-dark">
            <a class="navbar-brand" href="#"><img src="../images/site2.png" alt="" style="width: 4.7rem;"></a>
            <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">

                
                    <li class="nav-item">
                        <a class="nav-link" href="cadastroloja.php">Cadastrar Loja</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="cadastrarprod.php">Cadastrar Produto</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="meus_produtos.php">Meus Produtos</a>
                    </li>
                </ul>
                <a href="../logout.php" class="button nav-btn">Logout</a>
                <a href="ViewProfileVend.php" class="button nav-btn">Meu Perfil</a>
            </div>
        </nav>
    </div>
</header>

<section id="landing">
    <div class="container h-100">
        <div class="row h-100 justify-content-center align-items-center text-center">
            <div class="col-12">
                <div class="content">
                    <h1>Esta<span style="color: var(--primary)"></span><br> Página é apenas<span style="color: var(--primary)"> Para vendedores</span></h1>
                    <p>Está Querendo vender seu produto?<br> Aqui é o lugar certo.</p>
                    <a href="../telaprodutos.php" class="button rounded-circle">Comprar pelo Site</a>
                       
                    </a>
                </div>
            </div>
        </div>
    </div>
</section>

<?php
if (isset($_POST['cadastrar_loja'])) {
    $nome_loja = $_POST['nome_loja'];
    $descricao = $_POST['descricao'];

    $conn = new mysqli("localhost", "root", "", "sistema_login");

    if ($conn->connect_error) {
        die("Conexão falhou: " . $conn->connect_error);
    }

    
    $id_vendedor = $_SESSION['usuario_id']; 
    $sql = "INSERT INTO lojas (id_vendedor, nome_loja, descricao) VALUES ('$id_vendedor', '$nome_loja', '$descricao')";
    
    if ($conn->query($sql) === TRUE) {
        echo "Loja cadastrada com sucesso!";
    } else {
        echo "Erro ao cadastrar loja: " . $conn->error;
    }

    $conn->close();
}
?>

<?php

if (isset($_POST['cadastrar_produto'])) {
    $nome_produto = $_POST['nome_produto'];
    $nome_produto = $_POST['nome_produto'];
    $preco = $_POST['preco'];

  
    $conn = new mysqli("localhost", "root", "", "sistema_login");

    if ($conn->connect_error) {
        die("Conexão falhou: " . $conn->connect_error);
    }

  
    $id_vendedor = $_SESSION['usuario_id']; 
    $sql_loja = "SELECT id FROM lojas WHERE id_vendedor = '$id_vendedor' LIMIT 1";
    $result = $conn->query($sql_loja);
    if ($result->num_rows > 0) {
        $loja = $result->fetch_assoc();
        $id_loja = $loja['id'];
        
       
        $sql_produto = "INSERT INTO produtos (id_vendedor, id_loja, nome_produto, descricao, preco) 
                        VALUES ('$id_vendedor', '$id_loja', '$nome_produto', '$nome_produto', '$preco')";
        
        if ($conn->query($sql_produto) === TRUE) {
            echo "Produto cadastrado com sucesso!";
        } else {
            echo "Erro ao cadastrar produto: " . $conn->error;
        }
    } else {
        echo "Você precisa cadastrar sua loja antes de adicionar produtos.";
    }

    $conn->close();
}

?>

</body>

</html>
<?php
} else {
    echo "Você precisa estar logado como vendedor para acessar esta página.";
}
?>


