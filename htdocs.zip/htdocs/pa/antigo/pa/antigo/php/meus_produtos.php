<?php
session_start();

if (!isset($_SESSION['usuario_email']) || $_SESSION['usuario_tipo'] !== 'vendedor') {
    echo "Você precisa estar logado como vendedor para acessar esta página.";
    exit();
}

$conn = new mysqli("localhost", "root", "", "sistema_login");
if ($conn->connect_error) {
    die("Falha na conexão: " . $conn->connect_error);
}

// Busca o id_loja do vendedor logado
$stmt = $conn->prepare("SELECT id_loja FROM vendedor WHERE email = ?");
$stmt->bind_param("s", $_SESSION['usuario_email']);
$stmt->execute();
$resultado = $stmt->get_result();
$vendedor = $resultado->fetch_assoc();
$id_loja = $vendedor['id_loja'] ?? null;

if (!$id_loja) {
    echo "Vendedor não associado a uma loja.";
    exit();
}

// Buscar os produtos da loja do vendedor
$stmt_produtos = $conn->prepare("SELECT * FROM produto WHERE id_loja = ?");
$stmt_produtos->bind_param("i", $id_loja);
$stmt_produtos->execute();
$produtos = $stmt_produtos->get_result();
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Meus Produtos</title>
    <link rel="stylesheet" href="../css/meus_produtos.css">
</head>
<body>
<header style="position: relative;">
    <h1>Meus Produtos</h1>
    <a href="MenuVendedor.php" class="voltar-btn">Voltar</a>
</header>

<section class="product-list">
    <?php if ($produtos->num_rows > 0): ?>
        <?php while($produto = $produtos->fetch_assoc()): ?>
            <div class="product-card">
                <img src="../uploads/<?php echo htmlspecialchars($produto['imagem']); ?>" alt="<?php echo htmlspecialchars($produto['nome']); ?>">
                <div class="product-details">
                    <h3><?php echo htmlspecialchars($produto['nome']); ?></h3>
                    <p><?php echo htmlspecialchars($produto['descricao']); ?></p>
                    <span>R$ <?php echo number_format($produto['preco'], 2, ',', '.'); ?></span>
                    <div class="actions">
                        <a href="editar_produto.php?id=<?php echo $produto['id_produto']; ?>">Editar</a>
                        <form action="remover_produto.php" method="POST" onsubmit="return confirm('Tem certeza que deseja remover este produto?');">
                            <input type="hidden" name="id_produto" value="<?php echo $produto['id_produto']; ?>">
                            <button type="submit" class="delete-btn">Remover</button>
                        </form>
                    </div>
                </div>
            </div>
        <?php endwhile; ?>
    <?php else: ?>
        <p class="sem-produtos">Você ainda não cadastrou nenhum produto.</p>
    <?php endif; ?>
</section>

<a href="MenuVendedor.php" class="voltar-btn">Voltar ao Menu</a>

</body>
</html>

<?php
$conn->close();
?>
