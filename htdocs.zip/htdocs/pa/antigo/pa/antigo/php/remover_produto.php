<?php
session_start();

if (!isset($_SESSION['usuario_email']) || $_SESSION['usuario_tipo'] !== 'vendedor') {
    echo "Acesso negado.";
    exit();
}

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['id_produto'])) {
    $id_produto = intval($_POST['id_produto']);

    $conn = new mysqli("localhost", "root", "", "sistema_login");
    if ($conn->connect_error) {
        die("Erro na conexão: " . $conn->connect_error);
    }

    // Verifica se o produto pertence ao vendedor
    $stmt = $conn->prepare("SELECT p.id_produto FROM produto p 
                            INNER JOIN loja l ON p.id_loja = l.id_loja 
                            INNER JOIN vendedor v ON l.id_loja = v.id_loja 
                            WHERE p.id_produto = ? AND v.email = ?");
    $stmt->bind_param("is", $id_produto, $_SESSION['usuario_email']);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Pode deletar
        $stmt_delete = $conn->prepare("DELETE FROM produto WHERE id_produto = ?");
        $stmt_delete->bind_param("i", $id_produto);
        if ($stmt_delete->execute()) {
            header("Location: meus_produtos.php");
            exit();
        } else {
            echo "Erro ao remover produto.";
        }
        $stmt_delete->close();
    } else {
        echo "Produto não encontrado ou não pertence a você.";
    }

    $stmt->close();
    $conn->close();
}
?>
