<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "sistema_login";


$conn = new mysqli($servername, $username, $password, $dbname);


if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}


$sql = "SELECT * FROM produtos";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Produtos</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }
        header {
            background-color: #333;
            color: #fff;
            padding: 10px 0;
            text-align: center;
        }
        .container {
            width: 80%;
            margin: 30px auto;
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between;
        }
        .produto {
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            width: 30%;
            margin-bottom: 30px;
            transition: transform 0.3s ease-in-out;
        }
        .produto:hover {
            transform: scale(1.05);
        }
        .produto img {
            width: 50%;
            height: 50%;
        }
        .produto-info {
            padding: 10px;
        }
        .produto-info h3 {
            margin-top: 0;
            font-size: 1.6em;
        }
        .produto-info p {
            color: #555;
        }
        .preco {
            font-size: 1.4em;
            font-weight: bold;
            color: #2e8b57;
        }
        .produto-info .detalhes {
            margin-top: 10px;
            color: #007bff;
            text-decoration: none;
        }
        .produto-info .detalhes:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>


    <div class="container">
        <?php
        if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
                echo "<div class='produto'>";
                echo "<img src='uploads/" . $row['imagem_produto'] . "' alt='" . $row['nome_produto'] . "'>";
                echo "<div class='produto-info'>";
                echo "<h3>" . $row['nome_produto'] . "</h3>";
                echo "<p>" . $row['nome_produto'] . "</p>";
                echo "<div class='preco'>R$ " . number_format($row['preco'], 2, ',', '.') . "</div>";
                echo "<a href='#' class='detalhes'>Ver Detalhes</a>";
                echo "</div>";
                echo "</div>";
            }
        } else {
            echo "<p>Nenhum produto encontrado.</p>";
        }
        ?>
    </div>

    <?php
    // Fechar a conexão
    $conn->close();
    ?>

</body>
</html>
