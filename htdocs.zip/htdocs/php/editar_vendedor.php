<?php
// editar_vendedor.php
session_start();
include('conexao.php');

if (!isset($_SESSION['id_cliente']) || $_SESSION['tipo'] !== 'admin') {
    echo "Acesso negado.";
    exit();
}

if (!isset($_GET['id'])) {
    echo "ID do vendedor não especificado.";
    exit();
}

$id_vendedor = (int)$_GET['id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = $_POST['nome'];
    $email = $_POST['email'];
    
    $sql = "UPDATE vendedor SET nome = ?, email = ? WHERE id_vendedor = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssi", $nome, $email, $id_vendedor);
    if ($stmt->execute()) {
        echo "<p style='color: green;'>Vendedor atualizado com sucesso!</p>";
    } else {
        echo "<p style='color: red;'>Erro ao atualizar.</p>";
    }
}

$sql = "SELECT * FROM vendedor WHERE id_vendedor = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id_vendedor);
$stmt->execute();
$result = $stmt->get_result();
$vendedor = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Editar Vendedor</title>
    <style>
        body {
            background-color: #121212;
            color: #f5f5f5;
            font-family: Arial, sans-serif;
            padding: 20px;
        }
        input, button {
            padding: 10px;
            margin: 5px 0;
            background-color: #1e1e1e;
            color: white;
            border: 1px solid #333;
        }
        label { display: block; margin-top: 10px; }
    </style>
</head>
<body>
    <h2>Editar Vendedor</h2>
    <form method="POST">
        <label>Nome:</label>
        <input type="text" name="nome" value="<?php echo htmlspecialchars($vendedor['nome']); ?>" required>
        <label>Email:</label>
        <input type="email" name="email" value="<?php echo htmlspecialchars($vendedor['email']); ?>" required>
        <button type="submit">Salvar Alterações</button>
    </form>
    <a href="painelAdmin.php" style="color: lightblue;">Voltar ao Painel</a>
</body>
</html>