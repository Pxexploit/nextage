<?php
session_start();

// Verificação de acesso apenas para vendedores
if (!isset($_SESSION['usuario_email']) || $_SESSION['usuario_tipo'] !== 'vendedor') {
    echo "Você precisa estar logado como vendedor para acessar esta página.";
    exit();
}

$mensagem = "";
$tipo_mensagem = "";


// Conexão com o banco
$conn = new mysqli("localhost", "root", "", "sistema_login");
if ($conn->connect_error) {
    die("Falha na conexão: " . $conn->connect_error);
}

// Buscar loja do vendedor
$stmt_loja = $conn->prepare("SELECT id_loja FROM vendedor WHERE email = ?");
$stmt_loja->bind_param("s", $_SESSION['usuario_email']);
$stmt_loja->execute();
$result_loja = $stmt_loja->get_result();
$dados_loja = $result_loja->fetch_assoc();

$id_loja = $dados_loja['id_loja'] ?? null; // Agora define corretamente o $id_loja

if (!$id_loja) {
    $_SESSION['deubomcdst'] = 'semlojacds';
    header("Location: MenuVendedor.php");
    exit();
}

//notificação de erro que tem que cadastrar loja para acessar a tela
if (!$id_loja) {
    $_SESSION['deubomcdst'] = 'semlojacds';
    header("Location: MenuVendedor.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $nome_produto = htmlspecialchars(trim($_POST['nome_produto']));
    $descricao = htmlspecialchars(trim($_POST['descricao']));
    $preco = floatval($_POST['preco']);

    // Verificar se o arquivo foi enviado corretamente
    if (isset($_FILES['imagem_produto']) && $_FILES['imagem_produto']['error'] === UPLOAD_ERR_OK) {
        $imagem_tmp = $_FILES['imagem_produto']['tmp_name'];
        $imagem_original = $_FILES['imagem_produto']['name'];
        $extensao = strtolower(pathinfo($imagem_original, PATHINFO_EXTENSION));

        $permitidas = ['jpg', 'jpeg', 'png', 'webp'];
        if (!in_array($extensao, $permitidas)) {
            $mensagem = "Tipo de arquivo não permitido. Envie uma imagem JPG, JPEG, PNG ou WEBP.";
            $tipo_mensagem = "erro";
        } else {
            // Gerar nome único para a imagem
            $imagem_nome = uniqid('produto_', true) . '.' . $extensao;

            // Caminho absoluto para a pasta uploads na raiz do projeto
            $raiz = dirname(__DIR__, 1); // volta para a raiz da aplicação
            $diretorio_uploads = $raiz . "/uploads/";
            $imagem_destino = $diretorio_uploads . $imagem_nome;

            // Cria pasta se não existir
            if (!is_dir($diretorio_uploads)) {
                mkdir($diretorio_uploads, 0777, true);
            }

            if (move_uploaded_file($imagem_tmp, $imagem_destino)) {
                // Buscar vendedor e loja
                $stmt = $conn->prepare("SELECT id_vendedor, id_loja FROM vendedor WHERE email = ?");
                $stmt->bind_param("s", $_SESSION['usuario_email']);
                $stmt->execute();
                $resultado = $stmt->get_result();

                if ($resultado->num_rows > 0) {
                    $vendedor = $resultado->fetch_assoc();
                    $id_loja = $vendedor['id_loja'];
                    $stmt->close();

                    if ($id_loja) {
                        $id_vendedor = $vendedor['id_vendedor'];

                        $stmt_produto = $conn->prepare("INSERT INTO produto (nome, preco, descricao, imagem, id_loja, id_vendedor) VALUES (?, ?, ?, ?, ?, ?)");
                        $stmt_produto->bind_param("sdssii", $nome_produto, $preco, $descricao, $imagem_nome, $id_loja, $id_vendedor);

                        if ($stmt_produto->execute()) {
                            $mensagem = "Produto cadastrado com sucesso!";
                            $tipo_mensagem = "sucesso";
                        } else {
                            $mensagem = "Erro ao cadastrar produto: " . $conn->error;
                            $tipo_mensagem = "erro";
                        }
                        $stmt_produto->close();
                    } else {
                        $mensagem = "Você precisa estar associado a uma loja para cadastrar produtos.";
                        $tipo_mensagem = "erro";
                    }
                } else {
                    $mensagem = "Vendedor não encontrado.";
                    $tipo_mensagem = "erro";
                }
            } else {
                $mensagem = "Erro ao mover o arquivo para a pasta de destino.";
                $tipo_mensagem = "erro";
            }
        }
    } else {
        $mensagem = "Erro no upload da imagem.";
        $tipo_mensagem = "erro";
    }

    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <title>Cadastrar Produto</title>
    <link rel="stylesheet" href="../css/cdstroprod.css"> <!-- CSS separado -->
</head>

<body>
    <div class="container">
        <h2>Cadastrar Produto</h2>

        <?php if (!empty($mensagem)): ?>
            <div id="mensagemdeubom" class="<?php echo $tipo_mensagem; ?>">
                <?php echo $mensagem; ?>
            </div>
        <?php endif; ?>

        <form action="" method="POST" enctype="multipart/form-data">
            <label for="nome_produto">Nome do Produto:</label>
            <input type="text" id="nome_produto" name="nome_produto" required>

            <label for="descricao">Descrição:</label>
            <textarea id="descricao" name="descricao" required></textarea>

            <label for="preco">Preço:</label>
            <input type="number" id="preco" name="preco" step="0.01" required>

            <label for="imagem_produto">Imagem:</label>
            <input type="file" id="imagem_produto" name="imagem_produto" accept="image/*" required>

            <img id="preview-imagem" src="#" alt="Pré-visualização da imagem" style="display:none; max-width: 200px; margin-top: 10px; border-radius: 8px; box-shadow: 0 0 8px rgba(0,0,0,0.4);">

            <button type="submit">Cadastrar Produto</button>
            <button onclick="window.location.href='../php/MenuVendedor.php'" type="button">Voltar ao Menu</button>
        </form>
    </div>

    <script>
        document.getElementById('imagem_produto').addEventListener('change', function(event) {
            const arquivo = event.target.files[0];
            const preview = document.getElementById('preview-imagem');

            if (arquivo) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    preview.src = e.target.result;
                    preview.style.display = 'block';
                }
                reader.readAsDataURL(arquivo);
            } else {
                preview.src = '#';
                preview.style.display = 'none';
            }
        });
    </script>

    <script>
        //script para dar o tempo da mensagem de erro da notificação
        setTimeout(function() {
            const mensagem = document.getElementById('mensagem-flash');
            if (mensagem) {
                mensagem.classList.add('desaparecer');
            }
        }, 4000); // 4 segundos
    </script>

</body>

</html>