<?php
// excluir_vendedor.php
session_start();

if (!isset($_SESSION['id_cliente']) || $_SESSION['tipo'] !== 'admin') {
    echo "<div style='color: red;'>Acesso negado.</div>";
    exit();
}

include('conexao.php');

if (!isset($_GET['id'])) {
    echo "<div style='color: red;'>ID do vendedor não fornecido.</div>";
    exit();
}

$id = intval($_GET['id']);

$stmt = $conn->prepare("DELETE FROM vendedor WHERE id_vendedor = ?");
$stmt->bind_param("i", $id);

if ($stmt->execute()) {
    echo "<div style='color: green;'>Vendedor excluído com sucesso!</div>";
} else {
    echo "<div style='color: red;'>Erro ao excluir vendedor.</div>";
}
?>
