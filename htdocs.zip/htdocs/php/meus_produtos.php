<?php
session_start();

if (!isset($_SESSION['usuario_email']) || $_SESSION['usuario_tipo'] !== 'vendedor') {
    echo "Você precisa estar logado como vendedor para acessar esta página.";
    exit();
}

$conn = new mysqli("localhost", "root", "", "sistema_login");
if ($conn->connect_error) {
    die("Falha na conexão: " . $conn->connect_error);
}

// Busca o id_loja do vendedor logado
$stmt = $conn->prepare("SELECT id_loja FROM vendedor WHERE email = ?");
$stmt->bind_param("s", $_SESSION['usuario_email']);
$stmt->execute();
$resultado = $stmt->get_result();
$vendedor = $resultado->fetch_assoc();
$id_loja = $vendedor['id_loja'] ?? null;

if (!$id_loja) {
    $_SESSION['deubom'] = 'semloja';
    header("Location: MenuVendedor.php");
    exit();
}


// Buscar os produtos da loja do vendedor
$stmt_produtos = $conn->prepare("SELECT * FROM produto WHERE id_loja = ?");
$stmt_produtos->bind_param("i", $id_loja);
$stmt_produtos->execute();
$produtos = $stmt_produtos->get_result();
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <title>Meus Produtos</title>
    <link rel="stylesheet" href="../css/meus_produtos.css">
</head>

<body>

    <?php if (isset($_SESSION['mensagem_sucesso'])): ?>
        <div class="mensagem sucesso" id="mensagem-flash">
            <?php
            echo $_SESSION['mensagem_sucesso'];
            unset($_SESSION['mensagem_sucesso']);
            ?>
        </div>
    <?php endif; ?>

    <?php if (isset($_SESSION['mensagem_erro'])): ?>
        <div class="mensagem erro" id="mensagem-flash">
            <?php
            echo $_SESSION['mensagem_erro'];
            unset($_SESSION['mensagem_erro']);
            ?>
        </div>
    <?php endif; ?>

    <header>
        <div class="logo"><img src="../images/site2.png" alt="Logo" style="width: 4.7rem;"></div>
        <div class="search-bar">
            <input type="text" placeholder="Buscar produtos..." id="search-input">
        </div>

        <div class="titulo-carrinho">
            <h2>Meus Produtos</h2>
            <a href="MenuVendedor.php" class="btn-voltar">
                <img src="../images/voltar.png" alt="Voltar">
            </a>
        </div>
    </header>

    <section class="product-list">
        <?php if ($produtos->num_rows > 0): ?>
            <?php while ($produto = $produtos->fetch_assoc()): ?>
                <div class="product-card">
                    <img src="../uploads/<?php echo htmlspecialchars($produto['imagem']); ?>" alt="<?php echo htmlspecialchars($produto['nome']); ?>">
                    <div class="product-details">
                        <h3><?php echo htmlspecialchars($produto['nome']); ?></h3>
                        <p><?php echo htmlspecialchars($produto['descricao']); ?></p>
                        <span>R$ <?php echo number_format($produto['preco'], 2, ',', '.'); ?></span>
                        <div class="actions">
                            <a href="editar_produto.php?id=<?php echo $produto['id_produto']; ?>">Editar</a>
                            <form action="remover_produto.php" method="POST" onsubmit="return confirm('Tem certeza que deseja remover este produto?');">
                                <input type="hidden" name="id_produto" value="<?php echo $produto['id_produto']; ?>">
                                <button type="submit" class="delete-btn">Remover</button>
                            </form>
                        </div>
                    </div>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <p class="sem-produtos">Você ainda não cadastrou nenhum produto.<br>
                Cadastre um produto clicando <a href="../php/cadastrarprod.php"> aqui.</a></p>
        <?php endif; ?>
    </section>

    <script>
        setTimeout(function() {
            const mensagem = document.getElementById('mensagem-flash');
            if (mensagem) {
                mensagem.classList.add('desaparecer');
            }
        }, 4000); // 4 segundos
    </script>

</body>

</html>

<?php
$conn->close();
?>