<?php
session_start();

if (!isset($_SESSION['id_cliente']) || $_SESSION['tipo'] !== 'admin') {
    echo "<div style='color: red;'>Acesso negado.</div>";
    exit();
}

include('conexao.php');

if (!isset($_GET['id'])) {
    echo "<div style='color: red;'>ID do produto não fornecido.</div>";
    exit();
}

$id_produto = intval($_GET['id']);

$stmt = $conn->prepare("SELECT * FROM produto WHERE id_produto = ?");
$stmt->bind_param("i", $id_produto);
$stmt->execute();
$result = $stmt->get_result();
$produto = $result->fetch_assoc();

if (!$produto) {
    echo "<div style='color: red;'>Produto não encontrado.</div>";
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = $_POST['nome'];
    $preco = floatval($_POST['preco']);

    $novaImagem = $_FILES['nova_imagem'];
    $nomeImagemFinal = $produto['imagem'];

    if ($novaImagem['error'] === UPLOAD_ERR_OK) {
        $ext = pathinfo($novaImagem['name'], PATHINFO_EXTENSION);
        $nomeImagemFinal = uniqid('prod_') . '.' . $ext;
        move_uploaded_file($novaImagem['tmp_name'], "uploads/$nomeImagemFinal");

        if (!empty($produto['imagem']) && file_exists("uploads/{$produto['imagem']}") && $produto['imagem'] !== 'sem-imagem.png') {
            unlink("uploads/{$produto['imagem']}");
        }
    }

    $stmt = $conn->prepare("UPDATE produto SET nome = ?, preco = ?, imagem = ? WHERE id_produto = ?");
    $stmt->bind_param("sdsi", $nome, $preco, $nomeImagemFinal, $id_produto);

    if ($stmt->execute()) {
        echo "<div style='color: green;'>Produto atualizado com sucesso!</div>";
        $produto['nome'] = $nome;
        $produto['preco'] = $preco;
        $produto['imagem'] = $nomeImagemFinal;
    } else {
        echo "<div style='color: red;'>Erro ao atualizar produto.</div>";
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <title>Editar Produto</title>
    <style>
        body {
            background-color: #121212;
            color: #e0e0e0;
            font-family: Arial, sans-serif;
            padding: 20px;
        }

        input[type="text"],
        input[type="number"],
        input[type="file"] {
            padding: 8px;
            background-color: #1e1e1e;
            border: 1px solid #333;
            color: white;
            margin-bottom: 10px;
        }

        button {
            padding: 8px 12px;
            background-color: #333;
            border: none;
            color: white;
            cursor: pointer;
        }

        button,
        a {
            text-decoration: none;
            /* Remove sublinhado */
            color: inherit;
            /* Herda cor do elemento pai */
            /* Outras propriedades de estilo do botão aqui */
        }

        img {
            border: 1px solid #444;
            margin-bottom: 10px;
        }


        body {
            background-color: #151718;
            color: #e0e0e0;
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        nav {
            background-color: #1f1f1f;
            padding: 10px 20px;
            display: flex;
            justify-content: space-between;
        }

        nav a {
            color: #fff;
            margin: 0 10px;
            text-decoration: none;
            font-weight: bold;
        }

        .container {
            padding: 20px;
        }

        h2 {
            color: #2596be;
            margin-left: 38px;
            /* Move 20px para a direita */

        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 30px;
            background-color: #1e1e1e;
            table-layout: fixed;
        }

        th,
        td {
            padding: 10px 15px;
            border: 1px solid #2596be;
            text-align: left;
            vertical-align: middle;
            word-wrap: break-word;
            overflow-wrap: break-word;
            white-space: normal;
            font-size: 14px;
        }

        th {
            background-color: #333;
            font-weight: bold;
            text-align: left;
            color: #e0e0e0;
        }

        /* Evita quebra feia de botões */
        td a.btn-editar,
        td button.btn-excluir {
            white-space: nowrap;
        }

        /* Melhorando a responsividade em telas menores */
        @media (max-width: 768px) {

            table,
            thead,
            tbody,
            th,
            td,
            tr {
                display: block;
            }

            th,
            td {
                padding: 10px;
                text-align: left;
            }

            tr {
                margin-bottom: 15px;
                border-bottom: 2px solid #2596be;
            }

            th {
                background-color: #2596be;
                color: #000;
            }
        }


        .btn {
            padding: 5px 10px;
            background-color: #2596be;
            color: #000;
            border: none;
            cursor: pointer;
        }

        .btn-excluir {
            padding: 5px 10px;
            background-color: #dc3545;
            color: #000;
            border: none;
            cursor: pointer;
        }

        .btn-editar {
            padding: 5px 10px;
            background-color: #2596be;
            color: #000;
            border: none;
            cursor: pointer;
        }

        .btn:hover {
            background-color: #2596be;
        }

        header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 7px 10px;
            background-color: #151718;
            color: white;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }

        .logo {
            font-size: 10px;
            color: #e0dede;
        }

        header .search-bar input {
            padding: 5px;
            width: 300px;
            border: 1px solid #454444;
            border-radius: 8px;
            background: #232424;
            color: #ffffff;
            box-shadow: inset 0 1px 3px rgba(243, 242, 242, 0.1);
        }

        header .search-bar input:focus {
            border-color: #007BFF;
            outline: none;
        }

        .btn-voltar img {
            width: 50px;
            height: 50px;
            object-fit: contain;
            transition: transform 0.2s ease;
        }

        .btn-voltar:hover {
            transform: scale(1.1);
        }

        .text {
            font-size: 11px;
            text-align: center;
            color: #888;
            bottom: 10px;
            width: 100%;
        }

        input[type="text"],
        input[type="number"],
        input[type="file"] {
            padding: 8px;
            background-color: #1e1e1e;
            border: 1px solid #333;
            color: white;
            margin-bottom: 10px;
            width: 300px;
            /* ou outro valor como 250px, 100% etc. */
        }

        form {
            display: block;
            margin-top: 0em;
            unicode-bidi: isolate;
            margin-left: 38px;
            /* Move 20px para a direita */
        }
    </style>
</head>

<body>
    <header>
        <div class="logo"><img src="images/site2.png" alt="Logo" style="width: 4.7rem;"></div>
        <div class="search-bar">
            <h1 class="text">Página para editar produtos.</h1>
        </div>

        <div class="titulo-carrinho">
            <h2>Painel Admin</h2>
        </div>
    </header>

    <h2>Editar Produto</h2>
    <form method="POST" enctype="multipart/form-data">
        <label>Nome do Produto:</label><br>
        <input type="text" name="nome" value="<?php echo htmlspecialchars($produto['nome']); ?>" required><br>

        <label>Preço:</label><br>
        <input type="number" step="0.01" name="preco" value="<?php echo number_format($produto['preco'], 2, '.', ''); ?>" required><br>

        <label>Imagem atual:</label><br>
        <img id="preview-imagem" src="uploads/<?php echo htmlspecialchars($produto['imagem'] ?? 'sem-imagem.png'); ?>"
            alt="Imagem Produto"
            style="width: 100px; height: 100px; object-fit: cover;"><br>

        <label>Nova imagem (opcional):</label><br>
        <input type="file" name="nova_imagem" accept="image/*" onchange="mostrarPreview(event)"><br><br>

        <button type="submit">Salvar</button>
        <button type="submit"> <a href="painelAdmin.php">Voltar</button>
    </form>

    <script>
        function mostrarPreview(event) {
            const input = event.target;
            const imgPreview = document.getElementById('preview-imagem');

            if (input.files && input.files[0]) {
                const reader = new FileReader();

                reader.onload = function(e) {
                    imgPreview.src = e.target.result;
                }

                reader.readAsDataURL(input.files[0]);
            }
        }
    </script>
</body>

</html>