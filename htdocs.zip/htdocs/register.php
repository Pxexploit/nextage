<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro de Usuário</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/particles.js/2.0.0/particles.min.css">
    <link rel="stylesheet" href="css/stylesregister.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

    <style>
        #mensagemerro {
            padding: 4px;
            color: rgba(196, 28, 28, 0.92);
        }

        #particles-js {
            position: absolute;
            width: 100%;
            height: 100%;
            z-index: -1;
            opacity: 1; 
        }

        .particle {
            position: absolute;
            width: 15px;
            height: 15px;
            border-radius: 50%;
            background-color: #3498db;
            pointer-events: none;
            transition: transform 0.1s ease;
            box-shadow: 0 0 10px rgba(52, 152, 219, 0.6);
        }
    </style>
</head>
<body>

<?php
$erro = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['botaosubmit'])) {
        $conn = new mysqli("localhost", "root", "", "sistema_login");

        if ($conn->connect_error) {
            die("Conexão falhou: " . $conn->connect_error);
        }

        $nome = $_POST['nome'];
        $email = $_POST['email'];
        $senha = $_POST['senha']; // senha original para validar
        $tipo_usuario = $_POST['tipo_usuario'];
        $telefone = isset($_POST['telefone']) ? $_POST['telefone'] : null;

        // Verificação de senha com novos critérios
        if (
            strlen($senha) < 6 ||
            !preg_match('/[A-Z]/', $senha) ||
            !preg_match('/[0-9]/', $senha) ||
            !preg_match('/[\W_]/', $senha) // caractere especial
        ) {
            $erro = "A senha deve ter no mínimo 6 caracteres, com pelo menos 1 letra maiúscula, 1 número e 1 caractere especial.";
        } else {
            $senha_hash = password_hash($senha, PASSWORD_DEFAULT);

            $sql_check = "SELECT email FROM cliente WHERE email = '$email' 
                          UNION 
                          SELECT email FROM vendedor WHERE email = '$email'";
            $result_check = $conn->query($sql_check);

            if ($result_check->num_rows > 0) {
                $erro = "Este email já está registrado!";
            } else {
                if ($tipo_usuario === 'cliente') {
                    $sql_insert = "INSERT INTO cliente (nome, email, senha, telefone) 
                                   VALUES ('$nome', '$email', '$senha_hash', '$telefone')";
                } elseif ($tipo_usuario === 'vendedor') {
                    $sql_insert = "INSERT INTO vendedor (nome, email, senha, id_loja)  
                                   VALUES ('$nome', '$email', '$senha_hash', NULL)";
                }

                if ($conn->query($sql_insert) === TRUE) {
                    session_start();
                    $_SESSION['deubom'] = 'positivo';
                    header("Location: ../login.php");
                    exit; 
                } else {
                    $erro = "Erro ao cadastrar usuário: " . $conn->error;
                }
            }
        }

        $conn->close();
    }
}
?>

<div class="container">
    <div class="form-container">
        <h2>Cadastro de Usuário</h2>
        <form action="" method="POST">
            <div class="input-group">
                <label for="nome">Nome:</label>
                <input type="text" id="nome" name="nome" required>
            </div>

            <div class="input-group">
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" required>
            </div>

            <div class="input-group" id="telefone-group" style="display: none;">
                <label for="telefone">Telefone:</label>
                <input type="text" id="telefone" name="telefone" maxlength="15" placeholder="">
            </div>

            <div class="input-group">
                <label for="senha">Senha:</label>
                <div style="position: relative;">
                    <input type="password" id="senha" name="senha" required style="padding-right: 40px;">
                    <i class="fa-solid fa-eye" id="toggleSenha" onclick="toggleSenha()" style="
                        position: absolute;
                        right: 10px;
                        top: 50%;
                        transform: translateY(-50%);
                        cursor: pointer;
                        color: #aaa;
                    "></i>
                </div>

                <!-- Mensagem de erro PHP -->
                <div id="mensagemerro"><?php echo $erro; ?></div>

                <!-- Requisitos visíveis -->
                <ul id="requisitos-senha" style="font-size: 13px; color: #555; margin: 5px 0 10px; padding-left: 20px;">
                    <li id="req-comprimento"> Pelo menos 6 caracteres</li>
                    <li id="req-maiuscula"> Pelo menos 1 letra maiúscula</li>
                    <li id="req-numero"> Pelo menos 1 número</li>
                    <li id="req-especial"> Pelo menos 1 caractere especial (!@#$...)</li>
                </ul>
            </div>

            <div class="input-group">
                <label for="tipo_usuario">Tipo de Conta:</label>
                <select name="tipo_usuario" id="tipo_usuario" required>
                    <option value="cliente">Cliente</option>
                    <option value="vendedor">Vendedor</option>
                </select>
            </div>

            <button type="submit" name="botaosubmit">Cadastrar</button>
            <p>Já tem uma conta? <a href="login.php">Faça login aqui.</a></p>
        </form>
    </div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/particles.js/2.0.0/particles.min.js"></script>
<div id="particles-js"></div>
<div class="particle"></div>

<script>
  // Partículas de fundo
  function initParticles() {
      particlesJS('particles-js', {
          "particles": {
              "number": { "value": 30, "density": { "enable": true, "value_area": 800 }},
              "color": { "value": "#ffffff" },
              "shape": { "type": "circle", "stroke": { "width": 0, "color": "#ffffff" }},
              "opacity": { "value": 0.7 },
              "size": { "value": 4, "random": true },
              "line_linked": { "enable": false },
              "move": { "enable": true, "speed": 3, "direction": "none", "out_mode": "out" }
          },
          "interactivity": { "events": { "resize": true }},
          "retina_detect": true
      });
  }

  initParticles();

  const particle = document.querySelector('.particle');
  document.addEventListener('mousemove', (e) => {
      const mouseX = e.clientX;
      const mouseY = e.clientY;
      particle.style.left = mouseX - particle.offsetWidth / 2 + 'px';
      particle.style.top = mouseY - particle.offsetHeight / 2 + 'px';
  });

  // Mostrar ou esconder campo telefone
  const tipoUsuarioSelect = document.getElementById('tipo_usuario');
  const telefoneGroup = document.getElementById('telefone-group');

  tipoUsuarioSelect.addEventListener('change', () => {
      if (tipoUsuarioSelect.value === 'cliente') {
          telefoneGroup.style.display = 'block';
          document.getElementById('telefone').setAttribute('required', 'required');
      } else {
          telefoneGroup.style.display = 'none';
          document.getElementById('telefone').removeAttribute('required');
      }
  });

  window.addEventListener('DOMContentLoaded', () => {
      tipoUsuarioSelect.dispatchEvent(new Event('change'));
  });

  // Máscara de telefone
  document.getElementById('telefone').addEventListener('input', function (e) {
      let value = e.target.value.replace(/\D/g, '').slice(0, 11);
      let formatted = '';

      if (value.length >= 1) {
          formatted = '(' + value.slice(0, 2);
      }
      if (value.length >= 3) {
          formatted += ') ' + value.slice(2, 7);
      }
      if (value.length >= 8) {
          formatted += '-' + value.slice(7);
      }

      e.target.value = formatted;
  });

  // Mostrar/ocultar senha
  function toggleSenha() {
      const senhaInput = document.getElementById("senha");
      const toggleIcon = document.getElementById("toggleSenha");

      if (senhaInput.type === "password") {
          senhaInput.type = "text";
          toggleIcon.classList.remove("fa-eye");
          toggleIcon.classList.add("fa-eye-slash");
      } else {
          senhaInput.type = "password";
          toggleIcon.classList.remove("fa-eye-slash");
          toggleIcon.classList.add("fa-eye");
      }
  }

  // Validação visual da senha em tempo real
  const senhaInput = document.getElementById("senha");

  senhaInput.addEventListener("input", function () {
      const senha = senhaInput.value;

      document.getElementById("req-comprimento").style.color = senha.length >= 6 ? "green" : "#555";
      document.getElementById("req-maiuscula").style.color = /[A-Z]/.test(senha) ? "green" : "#555";
      document.getElementById("req-numero").style.color = /[0-9]/.test(senha) ? "green" : "#555";
      document.getElementById("req-especial").style.color = /[\W_]/.test(senha) ? "green" : "#555";
  });
</script>
</body>
</html>
