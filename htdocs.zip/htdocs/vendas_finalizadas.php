<?php
session_start();
include('conexao.php');

if (!isset($_SESSION['usuario_id']) || $_SESSION['usuario_tipo'] !== 'admin') {
    echo "Acesso negado.";
    exit();
}

$sqlVendas = "
SELECT v.id_venda, v.data, c.nome AS cliente_nome
FROM venda v
JOIN cliente c ON v.id_cliente = c.id_cliente
WHERE v.status = 'finalizado'
ORDER BY v.data DESC
";
$resultVendas = $conn->query($sqlVendas);

echo "<h2>Pedidos Finalizados</h2>";

while ($venda = $resultVendas->fetch_assoc()) {
    $id_venda = $venda['id_venda'];
    echo "<hr>";
    echo "<h3>Pedido #{$id_venda} - Cliente: " . htmlspecialchars($venda['cliente_nome']) . " - Data: " . $venda['data'] . "</h3>";

    $sqlItens = "
    SELECT p.nome_produto, p.preco, i.item_quantidade, (p.preco * i.item_quantidade) AS subtotal
    FROM item_venda i
    JOIN produto p ON i.id_produto = p.id_produto
    WHERE i.id_venda = ?
    ";
    $stmtItens = $conn->prepare($sqlItens);
    $stmtItens->bind_param("i", $id_venda);
    $stmtItens->execute();
    $resultItens = $stmtItens->get_result();

    $total = 0;
    echo "<table border='1' cellpadding='5'>";
    echo "<tr><th>Produto</th><th>Preço</th><th>Quantidade</th><th>Subtotal</th></tr>";
    while ($item = $resultItens->fetch_assoc()) {
        echo "<tr>
                <td>" . htmlspecialchars($item['nome_produto']) . "</td>
                <td>R$ " . number_format($item['preco'], 2, ',', '.') . "</td>
                <td>" . $item['item_quantidade'] . "</td>
                <td>R$ " . number_format($item['subtotal'], 2, ',', '.') . "</td>
              </tr>";
        $total += $item['subtotal'];
    }
    echo "<tr><td colspan='3'><strong>Total</strong></td><td><strong>R$ " . number_format($total, 2, ',', '.') . "</strong></td></tr>";
    echo "</table>";
}
