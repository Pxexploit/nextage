<?php
session_start();

// Verificação de acesso apenas para administradores
if (!isset($_SESSION['usuario_email']) || $_SESSION['usuario_tipo'] !== 'admin') {
    echo "Acesso negado. Somente administradores podem acessar esta página.";
    exit();
}

$conn = new mysqli("localhost", "root", "", "sistema_login");
if ($conn->connect_error) {
    die("Falha na conexão: " . $conn->connect_error);
}

// Verifica se o ID da loja foi passado
if (!isset($_GET['id_loja'])) {
    echo "ID da loja não especificado.";
    exit();
}

$id_loja = intval($_GET['id_loja']);
$mensagem = "";

// Busca os dados da loja
$stmt_loja = $conn->prepare("SELECT * FROM loja WHERE id_loja = ?");
$stmt_loja->bind_param("i", $id_loja);
$stmt_loja->execute();
$res_loja = $stmt_loja->get_result();
$loja = $res_loja->fetch_assoc();

if (!$loja) {
    echo "Loja não encontrada.";
    exit();
}

// Se o formulário foi enviado
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $nome = $_POST['nome_loja'];
    $endereco = $_POST['endereco_loja'];
    $telefone = $_POST['telefone_loja'];
    $cnpj_cpf = preg_replace('/\D/', '', $_POST['cnpj_cpf_loja']);

    $cnpj = null;
    $cpf = null;
    if (strlen($cnpj_cpf) === 14) {
        $cnpj = $cnpj_cpf;
    } elseif (strlen($cnpj_cpf) === 11) {
        $cpf = $cnpj_cpf;
    }

    $stmt_upd = $conn->prepare("UPDATE loja SET nome=?, endereco=?, telefone=?, cnpj=?, cpf=? WHERE id_loja=?");
    $stmt_upd->bind_param("sssssi", $nome, $endereco, $telefone, $cnpj, $cpf, $id_loja);

    if ($stmt_upd->execute()) {
        $mensagem = "Loja atualizada com sucesso!";
    } else {
        $mensagem = "Erro ao atualizar: " . $stmt_upd->error;
    }
}

$conn->close();
?>

<!-- HTML -->
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <title>Editar Loja - Admin</title>
</head>

<body>
    <h2>Editar Loja</h2>
    <?php if ($mensagem): ?>
        <p style="color: green; font-weight: bold;"><?php echo $mensagem; ?></p>
    <?php endif; ?>

    <form method="POST">
        <label>Nome da Loja:</label>
        <input type="text" name="nome_loja" value="<?php echo $loja['nome']; ?>" required><br>

        <label>Endereço:</label>
        <input type="text" name="endereco_loja" value="<?php echo $loja['endereco']; ?>" required><br>

        <label>Telefone:</label>
        <input type="text" name="telefone_loja" value="<?php echo $loja['telefone']; ?>" required><br>

        <label>CPF/CNPJ:</label>
        <input type="text" name="cnpj_cpf_loja" value="<?php echo $loja['cnpj'] ?? $loja['cpf']; ?>" required><br>

        <button type="submit">Salvar Alterações</button>
        <a href="gerenciar_lojas.php">Voltar</a>
    </form>
</body>

</html>